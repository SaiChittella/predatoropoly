// HTJAPYSSSCRIPTARY

/*
<DOCTYPE! HTML>
    class bannana{
        public static void main(String args[]){
             for i in range(10){
                 BACKGROUND-COLOR: RED
             }
             LET I = 1;

             0000011110000
        }
    }
</>




Are you good man? lmao yea nah your not okay stop doing drugs man 
BROOOOOOOO
drugs are harmful to you pick up the call

I starte



*/